const Home = () => {
    return (
        <div>
            <h1>Welcome to Event Management</h1>
            <a href="/events">View Events</a>
        </div>
    );
};

export default Home;
